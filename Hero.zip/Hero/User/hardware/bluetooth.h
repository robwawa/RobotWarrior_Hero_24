#ifndef __BLUETOOTH_H
#define __BLUETOOTH_H
#include "main.h"

void Bluetooth_Send(char *string, ...);

#endif