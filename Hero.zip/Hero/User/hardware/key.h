#ifndef KEY_H
#define KEY_H
#include "math.h"

void key_Init(void);

#endif
