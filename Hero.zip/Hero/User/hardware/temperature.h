#ifndef TEMPERATURE_H
#define TEMPERATURE_H
#include "main.h"

void temp_pwm_init(uint16_t arr, uint16_t psc);
void bmi_pwm_set(uint16_t pwm);


#endif
