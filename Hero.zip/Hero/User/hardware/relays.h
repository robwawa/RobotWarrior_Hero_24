#ifndef __RELAYS_H
#define __RELAYS_H
#include "main.h"

void Relays_Init(void);
void Relays_On(void);
void Relays_Off(void);
void Relays_Judge(void);

#endif
