#ifndef EXIT_H
#define EXIT_H
#include "main.h"

void exit_line3_init(void);
void exit_gyro_init(void);
void exti_line1_init(void);

#endif
