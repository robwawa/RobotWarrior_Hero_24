#ifndef RC_HANDOFF_H
#define RC_HANDOFF_H
#include "main.h"

bool_t switch_is_fric_on(int16_t ch);
bool_t switch_is_shoot(int16_t ch);

#endif
